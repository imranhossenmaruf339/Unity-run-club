// Include after data.js on every /admin/* page (except login.html).
// Redirects to login if not authenticated, or shows an access-denied
// message if authenticated but not an admin. Never trust the client
// alone — this is a UX convenience; real enforcement is the RLS
// policies in supabase-schema.sql.

const ADMIN_LINKS = [
  { href: 'index.html', label: 'Dashboard', key: 'dashboard' },
  { href: 'events.html', label: 'Manage Events', key: 'events' },
  { href: 'requests.html', label: 'Event Requests', key: 'requests' },
];

function renderAdminSidebar(activeKey) {
  const root = document.getElementById('admin-sidebar-root');
  if (!root) return;
  root.innerHTML = `
    <aside class="admin-sidebar">
      <div class="brand"><span class="dot"></span> URC Admin</div>
      ${ADMIN_LINKS.map(l => `<a href="${l.href}" class="${l.key === activeKey ? 'active' : ''}">${l.label}</a>`).join('')}
      <a href="../index.html" style="margin-top:1.4em; opacity:.7;">← View Site</a>
      <a href="#" id="admin-signout" style="opacity:.7;">Sign Out</a>
    </aside>`;
  document.getElementById('admin-signout').addEventListener('click', async (e) => {
    e.preventDefault();
    await UnityData.client.auth.signOut();
    location.href = 'login.html';
  });
}

async function requireAdmin() {
  const session = await UnityData.getSession();
  if (!session) { location.href = 'login.html'; return null; }
  const profile = await UnityData.getProfile(session.user.id);
  if (!profile || profile.role !== 'admin') {
    document.body.innerHTML = `
      <div style="max-width:520px;margin:80px auto;text-align:center;font-family:'Inter',sans-serif;padding:0 20px;">
        <h1 style="font-family:'Barlow Condensed';">Access Denied</h1>
        <p>This account isn't an admin yet. Ask an existing admin to grant access, or run the SQL in <code>supabase-schema.sql</code> to promote your account.</p>
        <a href="login.html" style="color:#00693e;font-weight:600;">Back to login</a>
      </div>`;
    return null;
  }
  return profile;
}
