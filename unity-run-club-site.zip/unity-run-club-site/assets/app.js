// Shared UI behaviors used on every public page.

const NAV_LINKS = [
  { href: 'index.html', label: 'Home', key: 'home' },
  { href: 'index.html#about', label: 'About', key: 'about' },
  { href: 'events.html', label: 'Events', key: 'events' },
  { href: 'index.html#gallery', label: 'Gallery', key: 'gallery' },
  { href: 'index.html#contact', label: 'Contact', key: 'contact' },
];

function renderNav(activeKey) {
  const root = document.getElementById('nav-root');
  if (!root) return;
  root.innerHTML = `
    <nav class="nav" id="site-nav">
      <div class="container nav-inner">
        <a href="index.html" class="brand"><span class="dot"></span> UNITY RUN CLUB</a>
        <ul class="nav-links">
          ${NAV_LINKS.map(l => `<li><a href="${l.href}" class="${l.key === activeKey ? 'active' : ''}">${l.label}</a></li>`).join('')}
        </ul>
        <a href="suggest-event.html" class="btn btn-primary nav-cta desktop">Suggest an Event</a>
        <button class="hamburger" id="hamburger" aria-label="Open menu" aria-expanded="false">
          <span></span><span></span><span></span>
        </button>
      </div>
    </nav>
    <div class="mobile-menu" id="mobile-menu">
      ${NAV_LINKS.map(l => `<a href="${l.href}">${l.label}</a>`).join('')}
      <a href="suggest-event.html" class="btn btn-primary">Suggest an Event</a>
    </div>
  `;

  const nav = document.getElementById('site-nav');
  const onScroll = () => {
    if (window.scrollY > 40) nav.classList.add('solid'); else nav.classList.remove('solid');
  };
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  const burger = document.getElementById('hamburger');
  const menu = document.getElementById('mobile-menu');
  burger.addEventListener('click', () => {
    const open = menu.classList.toggle('open');
    burger.classList.toggle('open', open);
    burger.setAttribute('aria-expanded', open);
    document.body.style.overflow = open ? 'hidden' : '';
  });
  menu.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
    menu.classList.remove('open'); burger.classList.remove('open');
    document.body.style.overflow = '';
  }));
}

function renderFooter() {
  const root = document.getElementById('footer-root');
  if (!root) return;
  root.innerHTML = `
    <footer>
      <div class="container">
        <div class="footer-grid">
          <div>
            <div class="brand" style="color:#fff;margin-bottom:.6em;"><span class="dot"></span> UNITY RUN CLUB</div>
            <p style="max-width:36ch;">Run For Bangladesh — building a stronger, healthier Bangladesh, one kilometer at a time.</p>
            <div class="social-row">
              <a href="https://www.facebook.com/profile.php?id=61581447125067" aria-label="Facebook" target="_blank" rel="noopener">f</a>
              <a href="https://facebook.com/groups/2349305025494610/" aria-label="Facebook Group" target="_blank" rel="noopener">g</a>
            </div>
          </div>
          <div>
            <h4>Explore</h4>
            <p><a href="index.html">Home</a></p>
            <p><a href="events.html">Events</a></p>
            <p><a href="suggest-event.html">Suggest an Event</a></p>
          </div>
          <div>
            <h4>Contact</h4>
            <p><a href="mailto:unityrunclub.urc@gmail.com">unityrunclub.urc@gmail.com</a></p>
            <p><a href="tel:+8801781674070">+880 1781 674070</a></p>
          </div>
        </div>
        <div class="foot-bottom">
          <span>© <span id="year"></span> Unity Run Club. All rights reserved.</span>
          <a href="admin/login.html" style="opacity:.6;">Admin</a>
        </div>
      </div>
    </footer>
  `;
  document.getElementById('year').textContent = new Date().getFullYear();
}

function initReveal() {
  const els = document.querySelectorAll('.reveal');
  if (!('IntersectionObserver' in window)) { els.forEach(el => el.classList.add('in')); return; }
  const io = new IntersectionObserver((entries) => {
    entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } });
  }, { threshold: 0.15 });
  els.forEach((el, i) => { el.style.setProperty('--i', i % 8); io.observe(el); });
}

function animateCounter(el, target, duration = 1400) {
  const start = performance.now();
  const from = 0;
  function tick(now) {
    const p = Math.min(1, (now - start) / duration);
    const eased = 1 - Math.pow(1 - p, 3);
    el.textContent = Math.round(from + (target - from) * eased).toLocaleString();
    if (p < 1) requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);
}

function initCounters(selector = '.stat .n') {
  const els = document.querySelectorAll(selector);
  if (!('IntersectionObserver' in window)) return;
  const io = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        animateCounter(e.target, Number(e.target.dataset.value || 0));
        io.unobserve(e.target);
      }
    });
  }, { threshold: 0.5 });
  els.forEach(el => io.observe(el));
}

function startCountdown(targetDateStr, els) {
  const target = new Date(targetDateStr).getTime();
  function tick() {
    const now = Date.now();
    const diff = target - now;
    if (diff <= 0) {
      els.wrap.innerHTML = '<div class="km" style="color:#ffd9b0;">Event Completed</div>';
      return;
    }
    const d = Math.floor(diff / 86400000);
    const h = Math.floor((diff % 86400000) / 3600000);
    const m = Math.floor((diff % 3600000) / 60000);
    const s = Math.floor((diff % 60000) / 1000);
    els.d.textContent = String(d).padStart(2, '0');
    els.h.textContent = String(h).padStart(2, '0');
    els.m.textContent = String(m).padStart(2, '0');
    els.s.textContent = String(s).padStart(2, '0');
    requestAnimationFrame(() => setTimeout(tick, 1000));
  }
  tick();
}

document.addEventListener('DOMContentLoaded', () => {
  initReveal();
});
