// Shared Supabase client + small data-access helpers.
// Loaded after config.js and the supabase-js CDN script.

const supa = window.supabase.createClient(
  window.UNITY_CONFIG.SUPABASE_URL,
  window.UNITY_CONFIG.SUPABASE_ANON_KEY
);

const UnityData = {
  client: supa,

  async getSession() {
    const { data } = await supa.auth.getSession();
    return data.session;
  },

  async getProfile(userId) {
    const { data, error } = await supa.from('profiles').select('*').eq('id', userId).single();
    if (error) return null;
    return data;
  },

  async isAdmin() {
    const session = await this.getSession();
    if (!session) return false;
    const profile = await this.getProfile(session.user.id);
    return profile?.role === 'admin';
  },

  async publishedEvents({ upcomingOnly = false, pastOnly = false, category = null } = {}) {
    let q = supa.from('events').select('*').eq('status', 'published');
    const today = new Date().toISOString().slice(0, 10);
    if (upcomingOnly) q = q.gte('event_date', today).order('event_date', { ascending: true });
    if (pastOnly) q = q.lt('event_date', today).order('event_date', { ascending: false });
    if (!upcomingOnly && !pastOnly) q = q.order('event_date', { ascending: true });
    if (category && category !== 'All') q = q.eq('category', category);
    const { data, error } = await q;
    if (error) { console.error(error); return []; }
    return data;
  },

  async featuredEvent() {
    const today = new Date().toISOString().slice(0, 10);
    const { data } = await supa.from('events')
      .select('*').eq('status', 'published').eq('featured', true)
      .order('event_date', { ascending: true }).limit(1);
    return data && data[0] ? data[0] : null;
  },

  async eventBySlug(slug) {
    const { data, error } = await supa.from('events').select('*').eq('slug', slug).single();
    if (error) return null;
    return data;
  },

  async team() {
    const { data } = await supa.from('team_members').select('*').order('sort_order');
    return data || [];
  },

  async communityStats() {
    const { data } = await supa.from('community_stats').select('*').order('sort_order');
    return data || [];
  },

  async submitEventRequest(payload) {
    return supa.from('event_requests').insert(payload);
  },

  async myRequests(userId) {
    const { data } = await supa.from('event_requests').select('*').eq('user_id', userId).order('created_at', { ascending: false });
    return data || [];
  },

  // ---- Admin-only calls (RLS also enforces this server-side) ----
  async allEvents() {
    const { data } = await supa.from('events').select('*').order('created_at', { ascending: false });
    return data || [];
  },
  async allRequests() {
    const { data } = await supa.from('event_requests').select('*').order('created_at', { ascending: false });
    return data || [];
  },
  async createEvent(payload) { return supa.from('events').insert(payload).select().single(); },
  async updateEvent(id, payload) { return supa.from('events').update({ ...payload, updated_at: new Date().toISOString() }).eq('id', id); },
  async deleteEvent(id) { return supa.from('events').delete().eq('id', id); },
  async updateRequest(id, payload) { return supa.from('event_requests').update({ ...payload, updated_at: new Date().toISOString() }).eq('id', id); },

  async uploadImage(file, folder = 'events') {
    const path = `${folder}/${Date.now()}-${file.name.replace(/\s+/g, '-')}`;
    const { error } = await supa.storage.from('event-images').upload(path, file);
    if (error) throw error;
    return supa.storage.from('event-images').getPublicUrl(path).data.publicUrl;
  },
};

window.UnityData = UnityData;
