// ============================================================
// Fill these in after creating your Supabase project:
// Supabase Dashboard > Project Settings > API
// SUPABASE_URL   = "Project URL"
// SUPABASE_ANON_KEY = "anon public" key (safe to expose — access
//   is enforced by the Row Level Security policies in
//   supabase-schema.sql, NOT by hiding this key).
// ============================================================
window.UNITY_CONFIG = {
  SUPABASE_URL: "YOUR_SUPABASE_PROJECT_URL",
  SUPABASE_ANON_KEY: "YOUR_SUPABASE_ANON_KEY",
};
