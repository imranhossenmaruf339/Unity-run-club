-- ============================================================
-- Unity Run Club — Supabase schema
-- Run this in Supabase SQL Editor (Project > SQL Editor > New query)
-- ============================================================

-- 1. PROFILES (extends Supabase auth.users with a role)
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text,
  email text,
  role text not null default 'user' check (role in ('user','admin')),
  created_at timestamptz not null default now()
);

-- Auto-create a profile row whenever someone signs up
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, name, email, role)
  values (new.id, new.raw_user_meta_data->>'name', new.email, 'user');
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- 2. EVENTS
create table if not exists events (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  slug text not null unique,
  description text,
  event_date date not null,
  event_time text,
  location text,
  distance text,        -- e.g. '5K', '10K', 'Marathon', 'Community Run', 'Charity Run'
  category text,         -- filter bucket: 5K / 10K / Marathon / Community Run / Charity Run
  cover_image text,
  route_map_url text,
  registration_url text,
  registration_deadline date,
  status text not null default 'draft' check (status in ('draft','published','archived')),
  featured boolean not null default false,
  schedule jsonb,         -- [{ "time": "5:30 AM", "label": "Check-in" }, ...]
  benefits jsonb,          -- ["Finisher Medal","T-shirt",...] — only confirmed items, admin-entered
  faq jsonb,               -- [{ "q": "...", "a": "..." }]
  participants_count int,
  results_url text,
  photos jsonb,            -- array of image URLs for past-event gallery
  created_by uuid references profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- 3. EVENT REQUESTS (public "suggest an event" submissions)
create table if not exists event_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id),
  name text not null,
  email text not null,
  phone text,
  event_name text not null,
  proposed_date date,
  location text,
  distance text,
  description text,
  organizer text,
  social_link text,
  image text,
  status text not null default 'pending' check (status in ('pending','approved','rejected','changes_requested')),
  admin_note text,          -- may contain private notes; only surfaced to requester when intended
  requester_note text,      -- note shown to the requester (e.g. what to change)
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- 4. TEAM (optional, admin-managed — do not seed with invented people)
create table if not exists team_members (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  position text,
  photo text,
  facebook text,
  instagram text,
  sort_order int default 0,
  created_at timestamptz not null default now()
);

-- 5. COMMUNITY STATS (optional, admin-managed — only real numbers)
create table if not exists community_stats (
  id uuid primary key default gen_random_uuid(),
  label text not null,     -- e.g. 'Runners', 'Events', 'Volunteers', 'Cities'
  value int not null,
  sort_order int default 0
);

-- ============================================================
-- ROW LEVEL SECURITY
-- ============================================================
alter table profiles enable row level security;
alter table events enable row level security;
alter table event_requests enable row level security;
alter table team_members enable row level security;
alter table community_stats enable row level security;

-- Helper: is the current user an admin?
create or replace function public.is_admin()
returns boolean as $$
  select exists (
    select 1 from profiles where id = auth.uid() and role = 'admin'
  );
$$ language sql security definer stable;

-- PROFILES: users can read their own row; admins can read all
create policy "read own profile" on profiles for select using (auth.uid() = id or public.is_admin());
create policy "update own profile" on profiles for update using (auth.uid() = id);

-- EVENTS: anyone can read published events; admins can read/write everything
create policy "public read published events" on events for select using (status = 'published' or public.is_admin());
create policy "admin write events" on events for insert with check (public.is_admin());
create policy "admin update events" on events for update using (public.is_admin());
create policy "admin delete events" on events for delete using (public.is_admin());

-- EVENT REQUESTS: anyone can submit; requester can read their own; admins read/manage all
create policy "anyone can submit request" on event_requests for insert with check (true);
create policy "requester or admin can read" on event_requests for select using (
  auth.uid() = user_id or public.is_admin()
);
create policy "admin manage requests" on event_requests for update using (public.is_admin());
create policy "admin delete requests" on event_requests for delete using (public.is_admin());

-- TEAM: public read, admin write
create policy "public read team" on team_members for select using (true);
create policy "admin write team" on team_members for insert with check (public.is_admin());
create policy "admin update team" on team_members for update using (public.is_admin());
create policy "admin delete team" on team_members for delete using (public.is_admin());

-- COMMUNITY STATS: public read, admin write
create policy "public read stats" on community_stats for select using (true);
create policy "admin write stats" on community_stats for insert with check (public.is_admin());
create policy "admin update stats" on community_stats for update using (public.is_admin());
create policy "admin delete stats" on community_stats for delete using (public.is_admin());

-- ============================================================
-- STORAGE (run in Storage settings, or via SQL below)
-- Create a public bucket called "event-images" for cover photos & gallery uploads.
-- ============================================================
insert into storage.buckets (id, name, public)
values ('event-images', 'event-images', true)
on conflict (id) do nothing;

create policy "public read event images" on storage.objects
  for select using (bucket_id = 'event-images');
create policy "admin upload event images" on storage.objects
  for insert with check (bucket_id = 'event-images' and public.is_admin());
create policy "admin delete event images" on storage.objects
  for delete using (bucket_id = 'event-images' and public.is_admin());

-- ============================================================
-- FIRST ADMIN ACCOUNT
-- 1. Sign up normally through /admin/login.html (it will create a 'user' profile).
-- 2. Then run this once, replacing the email:
--    update profiles set role = 'admin' where email = 'you@example.com';
-- ============================================================
